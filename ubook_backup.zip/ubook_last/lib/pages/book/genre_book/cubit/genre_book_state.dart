part of 'genre_book_cubit.dart';

abstract class GenreBookState extends Equatable {
  const GenreBookState();
  @override
  List<Object> get props => [];
}

class GenreBookInitial extends GenreBookState {}
