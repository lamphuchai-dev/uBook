import 'package:flutter/widgets.dart';

class BookInfo extends StatelessWidget {
  const BookInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
