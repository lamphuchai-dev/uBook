export 'view/install_extension_view.dart';
