export 'view/splash_view.dart';
