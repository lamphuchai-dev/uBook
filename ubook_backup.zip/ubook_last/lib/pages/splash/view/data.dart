String text = '''
Minh Nguyệt tông.

	Cửa chính chỗ, Tự Bạch một bộ áo trắng, hắn lúc này khí tức có chút yếu ớt. Bất cứ lúc nào cũng sẽ tiêu tán.

	"Sư đệ đây là muốn hồi hải ngoại? "Uống rượu Ứng Thủy Thiên có chút hiếu kỳ. Lúc này liền hắn một người tại, Ninh Nhân tiên tử nghỉ ngơi.

	"Đúng vậy a, muốn đi hải ngoại, dù sao ta chỉ là lưu lại một bộ phân thân tại tông môn."Đã lâu như vậy không sai biệt lắm."Tự Bạch vừa cười vừa nói.

	Trong con ngươi của hắn có một cỗ nhàn nhạt tiên ý.

	"Sư đệ đã đến thời điểm, vì cái gì còn không nguyện ý bước ra một bước này?"Sợ thất bại?"Ứng Thủy Thiên tò mò hỏi.

	Hắn cảm thấy ai cũng sẽ biết sợ, nhưng là trước mắt sư đệ tất nhiên sẽ không.

	"Nhanh, ta còn đang chờ, có lẽ còn có tốt hơn thời điểm, không vội."Tự Bạch vừa cười vừa nói."Ngươi muốn tại hải ngoại hoàn thành một bước này?"Ứng Thủy Thiên hơi kinh ngạc.

	"Sư huynh không biết thôi."Tự Bạch nhìn về phía hải ngoại phương hướng nói: "Hải ngoại phát sinh không ít sự tình, về sau cũng sẽ phát sinh không ít chuyện." "Hạo Thiên tông truyền đến ánh sáng?"Ứng Thủy Thiên hỏi.
  "Sở sư muội thế nhưng cảm thấy."Tự Bạch cười nói:

	"Mặc dù không biết cái này chỉ là cái gì, nhưng là hải ngoại lần này thật muốn phát sinh đại sự." "Là dạng gì đại sự?"Ứng Thủy Thiên thuận miệng hỏi.
  Cửa chính chỗ, Tự Bạch một bộ áo trắng, hắn lúc này khí tức có chút yếu ớt. Bất cứ lúc nào cũng sẽ tiêu tán.

	"Sư đệ đây là muốn hồi hải ngoại? "Uống rượu Ứng Thủy Thiên có chút hiếu kỳ. Lúc này liền hắn một người tại, Ninh Nhân tiên tử nghỉ ngơi.

	"Đúng vậy a, muốn đi hải ngoại, dù sao ta chỉ là lưu lại một bộ phân thân tại tông môn."Đã lâu như vậy không sai biệt lắm."Tự Bạch vừa cười vừa nói.

	Trong con ngươi của hắn có một cỗ nhàn nhạt tiên ý.

''';
