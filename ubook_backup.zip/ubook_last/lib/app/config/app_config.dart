class AppConfig {
  AppConfig._();
  static const extensionsUrl =
      "https://github.com/lamphuchai-dev/uBook/raw/main/ext-book/extensions.json";
}
