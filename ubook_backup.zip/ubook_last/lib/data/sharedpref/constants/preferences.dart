class Preferences {
  Preferences._();

  static const String isSignIn = "is_sign_in";
  static const String themeMode = "theme_mode";
  static const String currentLanguage = "current_language";
  static const String tokenFCM = "token-fcm";
}
