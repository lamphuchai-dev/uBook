package com.example.ubook

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
