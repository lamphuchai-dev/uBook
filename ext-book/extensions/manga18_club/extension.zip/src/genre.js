function genre(url) {
  return [
    { title: "Action", url: url + url + "/manga-list/action" },
    { title: "Mecha", url: url + "/manga-list/mecha" },
    { title: "18+", url: url + "/manga-list/18" },
    { title: "Mystery", url: url + "/manga-list/mystery" },
    { title: "Adult", url: url + "/manga-list/adult" },
    { title: "One shot", url: url + "/manga-list/one-shot" },
    { title: "Anime", url: url + "/manga-list/anime" },
    {
      title: "Psychological",
      url: url + "/manga-list/psychological",
    },
    { title: "Comedy", url: url + "/manga-list/comedy" },
    { title: "Romance", url: url + "/manga-list/romance" },
    { title: "Comic", url: url + "/manga-list/comic" },
    {
      title: "School Life",
      url: url + "/manga-list/school-life",
    },
    {
      title: "Doujinshi",
      url: url + "/manga-list/doujinshi",
    },
    { title: "Sci-fi", url: url + "/manga-list/sci-fi" },
    { title: "Drama", url: url + "/manga-list/drama" },
    { title: "Seinen", url: url + "/manga-list/seinen" },
    { title: "Ecchi", url: url + "/manga-list/Ecchi" },
    { title: "Shoujo", url: url + "/manga-list/Shoujo" },
    { title: "Fantasy", url: url + "/manga-list/Fantasy" },
    {
      title: "Shojou Ai",
      url: url + "/manga-list/shojou-ai",
    },
    {
      title: "Gender Bender",
      url: url + "/manga-list/Gender-Bender",
    },
    { title: "Shounen", url: url + "/manga-list/Shounen" },
    { title: "Harem", url: url + "/manga-list/Harem" },
    {
      title: "Shounen Ai",
      url: url + "/manga-list/shounen-ai",
    },
    {
      title: "Historical",
      url: url + "/manga-list/historical",
    },
    {
      title: "Slice of Life",
      url: url + "/manga-list/slice-of-life",
    },
    { title: "Horror", url: url + "/manga-list/Horror" },
    { title: "Smut", url: url + "/manga-list/Smut" },
    { title: "Josei", url: url + "/manga-list/Josei" },
    { title: "Sports", url: url + "/manga-list/Sports" },
    {
      title: "Live action",
      url: url + "/manga-list/live-action",
    },
    {
      title: "Supernatural",
      url: url + "/manga-list/supernatural",
    },
    { title: "Manhua", url: url + "/manga-list/Manhua" },
    { title: "Tragedy", url: url + "/manga-list/Tragedy" },
    { title: "Manhwa", url: url + "/manga-list/Manhwa" },
    {
      title: "Adventure",
      url: url + "/manga-list/Adventure",
    },
    {
      title: "Martial Art",
      url: url + "/manga-list/Martial-art",
    },
    { title: "Yaoi", url: url + "/manga-list/Yaoi" },
    { title: "Mature", url: url + "/manga-list/Mature" },
    { title: "Raw", url: url + "/manga-list/raw" },
  ];
}
